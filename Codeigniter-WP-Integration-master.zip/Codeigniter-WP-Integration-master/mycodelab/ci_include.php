<?php

/*
Include this in the following template files at the top:
- 404.php
- index.php
- archive.php
- archives.php
- links.php
- page.php
- search.php
- single.php
*/

$wp_ci['return'] = true;
require('codeigniter.php');
<?php
/**
 * Wordpress CodeIgniter Include file
 
 */
// --------------------------------------------------------------------


//NOT IN A FUNCTION 
if (!isset($wp_ci['index'])) $wp_ci['index'] = './../index.php';
if (!isset($wp_ci['uri'])) $wp_ci['uri'] = FALSE;
if (!isset($wp_ci['return'])) $wp_ci['return'] = FALSE;

$GLOBALS['wp_ci_is_wp'] = TRUE;

$wp_ci['index'] = realpath($wp_ci['index']);

if (empty($wp_ci['index']))
{
	 _e('Error finding the CodeIgniter bootstrap index file');
	exit;
}
$_SERVER['PATH_INFO'] = $wp_ci['uri'];
$_SERVER['REQUEST_URI'] = $wp_ci['uri'];

ob_start();
@include($wp_ci['index']);

if (!function_exists('get_instance'))
{
	_e('Error loading CodeIgniter');
	exit;
}
$GLOBALS['CI'] =& get_instance();

$GLOBALS['wp_ci_output'] = ob_get_contents();
ob_end_clean();

//  wp_ci_helper functions
require_once(APPPATH.'helpers/wordpress_helper.php');

if($wp_ci['return'])
{
	$output;
}
else
{
	echo $GLOBALS['wp_ci_output'];
}


?>
